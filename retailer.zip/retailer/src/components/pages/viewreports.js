import React from 'react';

function View() {
  return (
    <div className='view'>
      <h1>Reports</h1>
    </div>
  );
}

export default View;